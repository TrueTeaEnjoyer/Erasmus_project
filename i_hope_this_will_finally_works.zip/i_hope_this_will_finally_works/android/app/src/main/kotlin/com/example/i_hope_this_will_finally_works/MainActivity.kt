package com.example.i_hope_this_will_finally_works

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
