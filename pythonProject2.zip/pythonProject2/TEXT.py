import asyncio
from datetime import datetime, timedelta, timezone
from telethon import TelegramClient

# Replace the values with your own API ID, API hash, and phone number
api_id = "28883734"
api_hash = '0d9d0bd8edfe561b1f39464dcd94f8a3'
phone_number = '+420773905463'
group_name = -1001880073533

async def get_newest_message():
    # Create a Telegram client with the specified API ID, API hash, and phone number
    client = TelegramClient('session_name', api_id, api_hash)
    await client.connect()

    # Check if the user is already authorized, otherwise prompt the user to authorize the client
    if not await client.is_user_authorized():
        await client.send_code_request(phone_number)
        await client.sign_in(phone_number, input('Enter the code: '))

    # Get the entity of the specified group
    group = await client.get_entity(group_name)

    # List to store messages
    messages = []

    # Calculate the timestamp /change it for the right (-time)
    two_hours_ago_utc = datetime.now(timezone.utc) - timedelta(hours=2, minutes=0, seconds=0)

    # Get all messages in the group
    async for message in client.iter_messages(group, limit=100000):   #You can limit the amount of messages shown
        # Convert message date to UTC
        message_date_utc = message.date.astimezone(timezone.utc)
        # Check if the message was sent within the last 2 hours
        if message_date_utc > two_hours_ago_utc:
            # Convert the timestamp to local time zone and format it
            local_time = message.date.astimezone().strftime("%d-%m-%Y %H:%M:%S")
            # Get the timezone offset
            tz_offset = message.date.astimezone().strftime("%z")[:3] + ':' + message.date.astimezone().strftime("%z")[3:]
            # Get the name of the sender
            sender = await message.get_sender()
            sender_name = sender.first_name if sender else 'Unknown'
            messages.append(f"{local_time} ({tz_offset}) - {sender_name}: {message.text}")

    # Print the messages in reverse order
    for msg in reversed(messages):
        print(msg)

asyncio.run(get_newest_message())
